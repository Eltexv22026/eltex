#!/bin/bash

CHANEL="/tmp/run/cuckoo.pid"
LOG="cuckoo.log"

#Функция задания форматы вывода даты
get_date()
{
	date "+%d-%m-%Y %H:%M"
}

#Функция завершения работы
clean()
{
	echo "$(get_date) Shutdown!" >> $LOG
	rm -f "$CHANEL"
	exit 0
}

#Отслеживаем сигналы сигтерм и сигинт
trap clean SIGTERM SIGINT

#Создаём директорию для канала
mkdir -p /tmp/run

#Удаляем старый канал оставшийся от старых запусков
rm -f "$CHANEL"

#Создаём канал с указанием пути через переменную
mkfifo "$CHANEL"

#Дозаписываем в лог запись о запуске
echo "$(get_date) Startup!" >> $LOG

#Ожидание сообщения
while true; do
	if read -r line < "$CHANEL"; then
		#Проверка выражения
		if [[ "$line" =~ ^([a-zA-Z0-9_\-]+)\[([0-9]+)\] ]]; then
			NAME="${BASH_REMATCH[1]}"
			PID="${BASH_REMATCH[2]}"

			#Получаем случайное число от 2 до 10
			N=$(( RANDOM % 9 + 2 ))

			#Дозаписываем в лог результат
			echo "$(get_date) ${NAME}[${PID}] ${N}" >> $LOG
		fi
	fi
done
