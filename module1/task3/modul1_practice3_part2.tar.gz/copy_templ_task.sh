#!/bin/bash

#Получение имени самого скрипта без его полного пути
SCRIPT_NAME=$(basename "$0")
PID=$$
CHANEL="/tmp/run/cuckoo.pid"

get_date()
{
	date "+%d %m %Y %H:%M"
}

#Проверка имени
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
	echo "Я бригадир, сам не работаю"
	exit 0
fi

#Задаём имя лог файла
LOG_FILE="report_${SCRIPT_NAME%.*}.log"

#Дописываем в лог инфрмацию о запуске
echo "$(get_date) [${PID}] Скрипт запущен" >> "$LOG_FILE"

#Запрос времени через именованный канал
#Чтобы прочитать ответ, временно запускаем в фоне чтение лога и запоминаем сколько строк было до запроса
if [[ -f cuckoo.log ]]; then
	START_LINE=$(wc -l < cuckoo.log)
else
	START_LINE=0
fi

#Отправляем сообщения в канал
echo "${SCRIPT_NAME%.*}[${PID}]: how much time do I have?" > "$CHANEL"

#Ждем пока в логе появится новая строка с ответом
while true; do
	CURRENT_LINE=$(wc -l < cuckoo.log)
	if (( CURRENT_LINE > START_LINE )); then
		#Берём последнюю строку лога и берём случайное число
		LAST_LINE=$(tail -n 1 cuckoo.log)

		#Получаем последнее слово из строки
		N=$(echo "$LAST_LINE" | awk '{print $NF}')
		break
	fi
	sleep 0.1
done

#Засыпаем на N секунд
sleep "$N"

#Дозаписываем лог в в завершении работы
echo "$(get_date) [${PID}] Скрипт завершился, работал ${N} секунд." >> "$LOG_FILE"

