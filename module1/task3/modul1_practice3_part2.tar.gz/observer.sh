#!/bin/bash

CONF_FILE="observer.conf"
LOG_FILE="observer.log"

get_date()
{
	date "+%d-%m-%Y %H:%M"
}

#Проверка на существование файла конфига
if [[ ! -f "$CONF_FILE" ]]; then
	echo "Файл конфига не найден"
	exit 1
fi

#Если дошли до этой строчки, значит конфиг существует. Читаем его построчно
while read -r script_name; do
	#Игнорируем пустые строки и комменты
	[[ -z "$script_name" || "$script_name" =~ ^# ]] && continue

	is_running=0

	#Ищем процесс в папке proc
	for pid_dir in /proc/[0-9]*; do
		#Проверка файла cmdline
		if [[ -f "$pid_dir/cmdline" ]]; then
			#Если всё ок, то читаем содержимое. Если имя скрипта найдено, то grep вернёт 0
			if grep -q -a "$script_name" "$pid_dir/cmdline"; then
				is_running=1
				break
			fi
		fi
	done

	#Если процесса нет в /proc тогда запускаем его
	if (( is_running == 0 )); then
		if [[ -x "./$script_name" ]]; then
			nohup "./$script_name" > /dev/null 2>&1 &

		#Пишем лог о перезапуске
			echo "$(get_date) Скрипт $script_name не найден. Перезапуск." >> "$LOG_FILE"
		else
			echo "$(get_date) Ошибка: файл ./$script_name не найден или неисполняемый." >> "$LOG_FILE"
		fi
	fi
done < "$CONF_FILE"
